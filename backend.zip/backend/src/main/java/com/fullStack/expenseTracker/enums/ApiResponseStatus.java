package com.fullStack.expenseTracker.enums;

public enum ApiResponseStatus {
    SUCCESS,
    FAILED
}
