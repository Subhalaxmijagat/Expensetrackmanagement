package com.fullStack.expenseTracker.exceptions;

public class UserServiceLogicException extends Exception{

    public UserServiceLogicException(String message) {
        super(message);
    }

}